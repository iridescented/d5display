# turboAVR
A cool utility that allows your AVR codes to be loaded quickly on Windows. Currently only supports the Il Matto board from the University of Southampton. 
More information about the Il Matto Board: https://www.ecs.soton.ac.uk/outreach/kits/micro-arcana-series 

To use, put it in the same folder as your project, and then use it by calling "turboAVR yourcode.c" on CMD. Currently doesn't support external libraries. 
